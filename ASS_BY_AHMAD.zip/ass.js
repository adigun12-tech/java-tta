// ass 1
let name$ = prompt("What is your first name")

let names = prompt("What is your last name")

let age = prompt("What is your age")

let output = 'Hello ' + name$ + ' ' + names + ' I saw you are ' + age  + ' Year old'

console.log(name$)
console.log(names)
console.log(age)
console.log(output)






