/*console.log("volvo" + 16);
//Data types
//Sring
//number/integer
//Boolean
//undefined 
//float
//Bigint
//Null

//string
console.log('Moses')

alert('welcome to my website')

//integer

console.log(20)

var myclass = 'Laptop' + 20;

console.log(myclass)

//Boolean
console.log(true)*/

/*var firstName = prompt('what is your first name');
var lastName = prompt('what is your last name');
var bothName = firstName + lastName;
console.log(bothName)*/

alert('Welcome to My BMI calculator')

let Name = prompt('please input your name')
console.log(Name);

let height = prompt('input your height (m)')
console.log(height);

let  weight = prompt('input your weight (kg)')
console.log(weight);

let bmi = (weight*1000 * height ** 2)
console.log(bmi)


alert(Name + ' '  + 'your bmi is' + '' + bmi + 'kgm2').

alert('Thanks for using me')