// alert("Welcome")

// let Name =prompt("Enter Your Full Name")

// let output ="Start your BMI Calulator with us "+ Name

// let height =prompt("what is your height")

// let he = h

// let w = prompt("What is your weight")
    
// let we = w * 1000
    
// let mx = h * 2
    
// let result = mx * we
    
// let BMI =  'Dear ' + Name + ' Your BMI is ' + result
    
// let o = 'Dear ' + Name + ' kindly refresh for another trial'
    
// alert('THANKS FOR USING ME ' + Name)
    
// console.log(outputs)
// console.log( 'Your height is ' + h + 'cm')
// console.log( 'Your weight in gram is '+ we  + 'g')
// console.log(BMI + 'g/m2')
// console.log(o)
let names = prompt("what is your name")
let height = prompt("what is your height")

let weight = prompt("what is your weight")

 let h = height * height;
let kg = weight * 1000 ;
alert("Hello" + " " + names +   "  " + "your height is"   +  "  " +  h +   " " + "your weight is"  + " " +kg );


